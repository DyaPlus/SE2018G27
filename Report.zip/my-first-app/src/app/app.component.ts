import { Component, ViewChild } from '@angular/core';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-first-app';
  @ViewChild('f') signupForm :NgForm;
  

  patient= {
  patientname: '',
  Date : '',
  report : ''

  };
  submitted=false;
  onsumbit(form:NgForm)
  {
    this.submitted=true;
    this.patient.patientname = this.signupForm.value.patientData.patientname;
    this.patient.Date = this.signupForm.value.patientData.Date;
    this.patient.report = this.signupForm.value.report;
    this .signupForm.reset();

  }
}
