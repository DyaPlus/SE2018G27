import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {


  allownewserver = false;
  servercreationstatus = "no server was created";
  servername = ""
  servercreated = false; 
  constructor() { }

  ngOnInit() {
  }
  oncreateserver()
  {
    this.servercreated =true ; 
    
  }
  onupdateservername(event:Event)
  {
    this.servername = (<HTMLInputElement>event.target).value;

  }

}
